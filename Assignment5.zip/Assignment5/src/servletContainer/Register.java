package servletContainer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Register() { super(); }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String r_id = request.getParameter("rid");
		String r_fname = request.getParameter("rfirstname");
		String r_lname = request.getParameter("rlastname");
		String r_email = request.getParameter("remail");
		String r_password = request.getParameter("rpassword");
			
		request.getSession().setAttribute("rid", r_id);
		request.getSession().setAttribute("rfirstname", r_fname);
		request.getSession().setAttribute("rlastname", r_lname);
		request.getSession().setAttribute("remail", r_email);
		request.getSession().setAttribute("rpassword", r_password);
		response.sendRedirect("/Assignment5/register.jsp");
	}

}