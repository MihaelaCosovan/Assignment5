package servletContainer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertName
 */
@WebServlet("/InsertName")
public class InsertName extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public InsertName() { super(); }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String fname = request.getParameter("firstname");
		String lname = request.getParameter("lastname");
		String bdate = request.getParameter("birthdate");
		
		request.getSession().setAttribute("firstname", fname);
		request.getSession().setAttribute("lastname", lname);
		request.getSession().setAttribute("birthdate", bdate);
		response.sendRedirect("/Assignment5/insaddr.html");
	}

}