package servletContainer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertAddress
 */
@WebServlet("/InsertAddress")
public class InsertAddress extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public InsertAddress() { super(); }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mphone = request.getParameter("phone");
		String cemail = request.getParameter("email");
		String ccity = request.getParameter("city");
		
		request.getSession().setAttribute("phone", mphone);
		request.getSession().setAttribute("email", cemail);
		request.getSession().setAttribute("city", ccity);
		response.sendRedirect("/Assignment5/name_addr.jsp");
	}

}